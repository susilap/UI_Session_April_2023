function calc(x,y)
{
    console.log(x*y);
}
