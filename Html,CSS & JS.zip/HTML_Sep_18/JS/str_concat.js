console.log(10+10); // 20
console.log("hello "+"world")// hello world
console.log("hi "+200);
console.log(100+200 +"hello"+2+1);
console.log(100+200 +2+1);