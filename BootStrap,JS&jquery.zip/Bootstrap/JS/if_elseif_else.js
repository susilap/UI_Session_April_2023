const readLine = require('readline');

const rl =readLine.createInterface({input:process.stdin,output:process.stdout});
rl.question('Enter the Account Type?',(acc_type)=>{

// var acc_type="Current";
if(acc_type === "Savings")
{
    console.log("Its Saving Account");
}else if(acc_type === "Current")
{
    console.log("Its Current Account");
}else if(acc_type === "joined")
{
    console.log("Its joined Account");
}else{
    console.log("Invalid Account");
}})