function processNumbers(n1,n2,callback)
{
    const sum =n1+n2;
    callback(sum);
}


function logResult(result)
{
    console.log(`the result is :${result}`);
}

processNumbers(23,43,logResult);