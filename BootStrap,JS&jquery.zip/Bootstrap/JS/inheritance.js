class Product // Product is parent class
{
    constructor(id,name,price)
    {
        this.id=id;
        this.name=name;
        this.price=price;
    }
}

class Accounts  extends Product // Accounts is child class
{
    constructor(id,name,price,discount)
    {
        super(id,name,price); this.discount=discount;
    }
     receipt() { this.discount=this.price*this.discount/100;}
     report(){
        console.log("Product id:"+this.id);console.log("Product name:"+this.name);
        console.log("Product Price:"+this.price);console.log("Discount:"+this.discount);
    }
}

var obj = new Accounts(101,"John",5000,20);
obj.receipt(); obj.report();