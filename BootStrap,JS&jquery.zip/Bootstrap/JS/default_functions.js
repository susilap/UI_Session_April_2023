function greet(name='Kalam'){
    console.log(`Hello,${name}`);
    console.log("hello,"+name);
}

greet();

greet('Sachin');
