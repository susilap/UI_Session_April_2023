class Pet
{
    display()
    {
        console.log("parent class is called");
    }
}

class Dog extends Pet
{
    display() 
    {
        console.log("Dog class is called");
    }
}

var obj = new Dog(); obj.display();