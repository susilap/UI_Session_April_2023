class BankAccount
{
    #balance=0; // private property

    getBalance(){return this.#balance;}

    setBalance(balance)
    {
        this.#balance = balance;
    }

}

const acc_obj = new BankAccount();
acc_obj.setBalance(10000);
console.log(acc_obj.getBalance());
