var days=["sun","mon","Tue","wed","Thu","Fri","Sat","sun"];

for(const i of days)
{
    console.log(i);
}

