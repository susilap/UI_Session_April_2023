const readLine = require('readline');
const rl =readLine.createInterface({input:process.stdin,output:process.stdout});
rl.question('Enter the Product Price?',(pro_price)=>{ 

if(pro_price >=10000 && pro_price <=15000)
{
    var discount = pro_price * 15/100;
    console.log("Discount is :"+discount);
}
else if(pro_price >=15000 && pro_price <=25000 ){

 var discount = pro_price * 20/100;
 console.log("Discount is :"+discount);
}else if(pro_price >=25000 ){

       var discount = pro_price * 23/100;
     console.log("Discount is :"+discount);
}else{
        
        var discount = pro_price * 10/100;
         console.log("Discount is :"+discount);
        
}})

