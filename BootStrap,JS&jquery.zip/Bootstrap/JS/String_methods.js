const str='Hello, World';
console.log(str.charAt(3)); // 3rd index

const str1='sachin'; const str2='Tendulkar';
console.log(str1.concat('',str2));

console.log(str.includes('World')); console.log(str.indexOf('World'));
console.log(str.slice(0,5)); console.log(str.toLocaleLowerCase());
console.log(str.toUpperCase());
