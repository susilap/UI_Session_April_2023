let pan_no = "GKTAD9834K"
console.log("Permanent Account Number is:"+pan_no);
//duplicate is not allowed
// var pan_no = "GKTAD8756P"
// console.log("Permanent Account Number is:"+pan_no);

// reinitialize the variable
pan_no = "HJKK57223H"
console.log("Updated Permanent Account Number is:"+pan_no);

{
    let pan_no = "WERD78669G";
    console.log("inside the block Permanent Account Number is:"+pan_no);

}
//Local  scope
console.log("outside the block Permanent Account Number is:"+pan_no);
