function slowTask()
{
    setTimeout(()=>console.log("slow Task Completed"),5000);
}

function fastTask()
{
    console.log("fast task completed");
}


slowTask();fastTask();slowTask();fastTask();