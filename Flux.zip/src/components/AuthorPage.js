import React from 'react';
import * as authorActions from '../Actions/AuthorAction'
import authorstore from '../Store/AuthorStore';

class AuthorPage extends React.Component
{
    constructor()
    {
        super();
        this.getAuthors=this.getAuthors.bind(this);
        this.state={
            authors: authorstore.getAllAuthors()
        }
    }
    componentWillMount()
    {
        authorstore.on("change",this.getAuthors);
    }

    getAuthors()
    {
        this.setState({authors:authorstore.getAllAuthors()})
    }
    createAuthor(){authorActions.createAuthor(this.refs.aname.value);}
    render()
    {
        const authors = this.state.authors;
        var li=authors.map((author)=><li>{author.authorName}</li>);
        return(
            <>
            <table borde="3">
                <tr><td>Enter Author Name:</td>
                <td><input type="text" ref="aname"/></td></tr>
                <tr><td><button onClick={this.createAuthor.bind(this)}>Create Author</button></td></tr>
                <tr><td><h2>Author Details</h2>
                <ul>{li}</ul></td></tr>
            </table>
            </>
        )
    }
}
export default AuthorPage;