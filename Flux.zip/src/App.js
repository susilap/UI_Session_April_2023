import logo from './logo.svg';
import './App.css';
import AuthorPage from './components/AuthorPage';

function App() {
  return (
    <div className="App">
      <AuthorPage/>
    </div>
  );
}

export default App;
