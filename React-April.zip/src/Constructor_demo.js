
import { Component } from "react";

class Constructor_demo extends Component{
    constructor(props)
    {
        super(props);
        this.state = {favoriteColor:"red"}
    }
  
    render(){
        return(<>
        <h1>My favoriteColor is {this.state.favoriteColor}</h1>
        </>)
    }
  }
  
  export default Constructor_demo;