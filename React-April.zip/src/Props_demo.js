
function Props_demo(props)
{
    return(<div>
        <h2>{props.title}</h2>
        <p>{props.description}</p>
        <ul>
         {props.items.map((item)=>(<li key={item}>{item}
            
            </li>))}
        </ul>
    </div>)
}

export default Props_demo;