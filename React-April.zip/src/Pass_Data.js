
function Pass_Data()
{
    const car_Info={color:"red",model:"2023"}
   return(<>
   
   <h1>Properties got from another component</h1>
   <Get_Props color={car_Info} />
   </>) 
}

function Get_Props (props)
{
    return <h1>I am a {props.color.model}! color </h1>
}


export default Pass_Data;