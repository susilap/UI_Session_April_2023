import React, { useState } from 'react';
function Form_Demo() {
  const [name, setName] = useState('Name1');
  const [email, setEmail] = useState('name@gmail.com');
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Name:', name);
    console.log('Email:', email);
  };
  return (
    <form onSubmit={handleSubmit}>
      <label>
        Name:
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <br /><br />
      <label>
        Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label><br />
      <br />
      <button type="submit">Submit</button>
    </form> );}
export default Form_Demo;
