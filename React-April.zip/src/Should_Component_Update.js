import { Component } from "react";
class Should_Component_Update extends Component
{
    constructor(props)
    {
        super(props);
        this.state={userName:"admin"};
    }
    shouldComponentUpdate()
    {
        return true;
    }

    changeUserName = () =>{
        this.setState({userName:"Accounts"});
    }

    render(){
        return(<>
        <h1> User Name is:{this.state.userName}</h1>
<button type="button" onClick={this.changeUserName}>
    Change the User</button>
        </>)
    }
}


export default Should_Component_Update;