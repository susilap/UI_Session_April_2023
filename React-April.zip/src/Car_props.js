import styles from './my-style.css'

function Car(props)
{
    return <h1>i am a {props.brand}</h1>
}


export default Car;