
function List_demo(){
    const Fruits = ['Apple','Orange','Mango','Banana','Grape','Banana','Grape'];

    return(
        <div>
            <h2>List of Fruits:</h2>
            <ul>
                {Fruits.map((Fruits,index)=>(
                    <li key={index}>{Fruits}</li>
                ))}
            </ul>
        </div>
    )
}

export default List_demo;