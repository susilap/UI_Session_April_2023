import React, { useState } from 'react';
import styles from './my-style.css'
function ProductForm() {
  const [productData, setProductData] = useState({
    name: '',
    price: '',
    description: '',
    image: '',
  });
  const handleChange = (event) => {
    const { name, value } = event.target;
    setProductData({ ...productData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(productData);
    // You can use this data to submit a form or send it to a server
  };
  return (
    <form onSubmit={handleSubmit} className="cls">
      <label htmlFor="name">Product Name</label>
      <input
        type="text"
        name="name"
        id="name"
        value={productData.name}
        onChange={handleChange}
      /><br/><br/>
      <label htmlFor="price">Price</label>
      <input
        type="number"
        name="price"
        id="price"
        value={productData.price}
        onChange={handleChange}
      /><br/><br/>
      <label htmlFor="description">Description</label>
      <textarea
        name="description"
        id="description"
        value={productData.description}
        onChange={handleChange}
      ></textarea><br/><br/>
      <label htmlFor="image">Image URL</label>
      <input
        type="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMc6nQEdScA34FQ-jYPVw17RO_QRwzqPLOCg&usqp=CAU"
        name="image"
        id="image"
        value={productData.image}
        onChange={handleChange}
      /><br/><br/>
      <button type="submit">Add Product</button>
    </form>
  );
}
export default ProductForm;
