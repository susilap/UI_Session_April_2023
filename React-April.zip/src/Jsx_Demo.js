
const Jsx = () =>{
    return(<>
    <h1>Jsx Demo!..</h1>
    <p> This is a demo of JSX in React. </p>
    </>)
}


export default Jsx;