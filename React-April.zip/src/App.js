import Product from "./Product";
import Jsx from "./Jsx_Demo";
import Constructor_demo from "./Constructor_demo";
import Get_Derived_State from "./Get_Derived_State";
import Component_did_mount from "./Component_did_mount";
import Should_Component_Update from "./Should_Component_Update";
import Get_Snap_Shot from "./Get_Snap_Shot";
import Component_Will_Unmount from "./Component_Will_Unmount";
import Car from "./Car_props";
import Pass_Data from "./Pass_Data";
import Props_demo from "./Props_demo";
import Person from "./Person";
import Counter from "./Counter";
import Employee_state from "./Employee_state";
import Conditional_render from "./Condtional_render";
import List_demo from "./List_demo";
import Form_Demo from "./Form_demo";
import ProductForm from "./ProductForm";
import Bootstrap_demo from "./Bootstrap_demo";
function App() {

  const fruits=["apple","orange","grape","mango","banana"]
  return (
    <div className="App">
      <h1>Welcome to React Application</h1>
      <hr/>
      <Product />
      <hr/>
      <Jsx/>
      <hr/>
      <Constructor_demo/>
      <hr/><Get_Derived_State fcolor="yellow"/>
      <hr/><Component_did_mount/>
      <hr/><Should_Component_Update/>
      <hr/><Get_Snap_Shot/>
      <hr/><Component_Will_Unmount/>
      <hr/><Car brand="Audi"/>
      <hr/><Pass_Data/>
      <hr/><Props_demo title="My Title"
       description="My Description" 
       items={fruits}/>
<Person name="Alice" age="27" 
occupation="Software Engineer"/>
<Person name="George" age="30"
 occupation="Production Manager"/>
 <hr/><Counter/>
 <hr/><Employee_state empid="10011" empname="Jackson" department="Developemnt"/>
 <hr/><Conditional_render/>
 <hr/><List_demo/>
 <hr/><Form_Demo/>
 <hr/><ProductForm/>
 <hr/><Bootstrap_demo/>
    </div>
  );
}
export default App;
