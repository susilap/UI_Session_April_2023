import React from "react";
import styles from './my-style.css'
class Conditional_render extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoggedIn: false
    };
    this.handleLogin = this.handleLogin.bind(this);
    this.handleLogout = this.handleLogout.bind(this);
  }

  handleLogin() {
    this.setState({
      isLoggedIn: true });}
  handleLogout() {
    this.setState({
      isLoggedIn: false });}
  render() {
    const isLoggedIn = this.state.isLoggedIn;
    
        // const myStyle = {
        //     color:"red",
        //     backgroundColor:'pink',
        //     padding:"10px"
        // }
    
    return (
      <div>
        {isLoggedIn ? (
          <div className="cls">
            <h1>Welcome, User!</h1>
            <button onClick={this.handleLogout}>Logout</button>
          </div>
        ) : (
          <div className="cls">
            <h1 >Please Login</h1>
            <button onClick={this.handleLogin}>Login</button>
          </div>
        )}
      </div>
    ); }}
export default Conditional_render;
